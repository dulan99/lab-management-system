<?php

require_once realpath(dirname(__FILE__)).'/../classes/AbstractPage.php';

abstract class AbstractLoggedInPage extends AbstractPage
{
	protected $user=null;
	
	function __construct()
	{
		parent::__construct();
		
		$this->user=Utils::loginCheck();
		$this->loggedIn=($this->user!=null);
	}	
}