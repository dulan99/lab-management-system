<?php

require_once realpath(dirname(__FILE__)).'/../config.php';

require_once realpath(dirname(__FILE__)).'/../classes/Utils.php';
require_once realpath(dirname(__FILE__)).'/../classes/DbUtils.php';
require_once realpath(dirname(__FILE__)).'/../classes/Action.php';

abstract class AbstractPage
{
	protected $loggedIn=false;
	protected $showMenu=true;
	
	function __construct()
	{
		date_default_timezone_set("Europe/London");
	}	
	
	abstract function run();

	protected function getRequestValue($name, $defaultVal=null)
	{
		$val=$defaultVal;
		if (array_key_exists($name, $_POST))
		{
			$val=$_POST[$name];
		}
		else if (array_key_exists($name, $_GET))
		{
			$val=$_GET[$name];
		}
		return $val;
	}
	
	
	protected function loadComponent($componentName)
	{
		require_once realpath(dirname(__FILE__)).'/../components/'.$componentName; 
	}
	
	public function setUserAndGoToHomepage($userId)
	{
		Action::log($userId, "Logged in");
	
		Utils::setUserId($userId);
		header("Location: main.php");
		exit;
	}
	
	protected function showError($msg)
	{
		echo $msg;
		exit;
	}
	
	public static function runPage($name)
	{
		$obj=new $name();
		$obj->run();
	}
}