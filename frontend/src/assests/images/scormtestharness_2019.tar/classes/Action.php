<?php

require_once realpath(dirname(__FILE__)).'/DbUtils.php';

class Action
{
	public $id;
	public $userId;
	public $message;
	public $datetime;
	//pseudo
	public $username;
	
	public static function log($userId, $message)
	{
		$action=new Action($userId, $message);
		$action->datetime=date('Y-m-d H:i');
		$action->userId=$userId;
		$action->message=$message;
		$action->save();
		return $action;
	}
	
	
	public function __construct()
	{
	}
	
	public function save()
	{
		if ($this->id>0)
		{
			//update
			DbUtils::exec(
				"update Action set user_id=:userId, message=:message where action_id=:id", 
				array(
					'message' 	=> $this->message,
					'userId' 	=> $this->userId, 
					'action_id' => $this->id,
					'datetime'  => $this->datetime
				)
			);
		}	
		else
		{
			//create
			$db=DbUtils::getConnection();
			DbUtils::exec(
				"insert into Action (user_id, message, datetime) values (:userId, :message, :datetime)", 
				array(
					'message' 	=> $this->message,
					'userId' 	=> $this->userId,
					'datetime'  => $this->datetime
				), 
				$db
			);
			$this->id=DbUtils::getLastInsertId($db);
		}
	}
	
	public static function getAllActions()
	{
		return DbUtils::fetchAllObjects(
			"select a.action_id id, a.user_id as userId, a.message, a.datetime, ifnull(u.name,'(anonymous)') username 
				from Action a
				left join User u on u.user_id=a.user_id
				order by a.action_id desc",
			'Action'
		);
	}
}