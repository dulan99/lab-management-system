<?php

class DbUtils
{

	/** @return PDO */
	public static function getConnection()
	{
		$sqlite=false;
		if ($sqlite)
		{
			$dbFile=realpath(dirname(__FILE__)).'/../test-harness.sq3';
			
			$dsn="sqlite:$dbFile";
			
			$pdo=new PDO($dsn);
		}
		else
		{
			//MySQL
			$pdo=new PDO(
				"mysql:host=".DB_HOST.";port=".DB_PORT.";dbname=".DB_NAME.";charset=utf8",
				DB_USERNAME,
				DB_PASSWORD
			);
		}
		
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		
		return $pdo;
	}

	public static function fetchAllObjects($query, $className='stdClass', $params=null, $db=null, $ctrArgs=Array())
	{
		try
		{
			if ($db == null)
			{
				$db = self::getConnection();
			}

			if ($params == null)
			{
				$stat = $db->query($query);
			}
			else
			{
				$stat = $db->prepare($query);
				$stat->execute($params);
			}

			$rs = $stat->fetchAll(PDO::FETCH_CLASS, $className, $ctrArgs);

		}
		catch (Exception $e)
		{
			error_log('fetchAllObjects: '.$e->getMessage());

			throw $e;
		}

		return $rs;
	}

	public static function fetchObject($query, $className='stdClass', $params=null, $db=null, $ctrArgs=Array())
	{
		try
		{
			if ($db == null)
			{
                $db = self::getConnection();
			}

            if ($params == null)
            {
                $stat = $db->query($query);
            }
            else
            {
                $stat = $db->prepare($query);
                $stat->execute($params);
            }
			$object = $stat->fetchObject($className, $ctrArgs);
		}
		catch (Exception $e)
		{
			error_log('fetchObject: '.$e->getMessage());

			throw $e;
		}

		return $object;
	}

	public static function execAndReadInt($query, $defaultValue, $parms=null, $db=null)
	{
		if ($db == null)
		{
            // Define a default connection or avoid null db parameter
            $db = self::getConnection();
		}

		$stat = $db->prepare($query);
		$stat->execute($parms);
		$val=$defaultValue;
		if($row=$stat->fetch())
		{
			$val=$row[0];
		}
		return $val;
	}
	
	
	public static function execAndReadVal($query, $defaultValue, $parms=null, $db=null)
	{
		if ($db == null)
		{
            // Define a default connection or avoid null db parameter
            $db = self::getConnection();
		}

		$stat = $db->prepare($query);
		$stat->execute($parms);
		$val=$defaultValue;
		if($row=$stat->fetch())
		{
			$val=$row[0];
		}
		return $val;
	}


	/** @return PDOStatement */
	public static function exec($query, $parms=null, $db=null)
	{
		if ($db == null)
		{
            $db = self::getConnection();
		}

		$stat = $db->prepare($query);
		$stat->execute($parms);
		return $stat;
	}

	public static function getZendDate($value)
	{
		return new Zend_Date($value, Zend_Date::ISO_8601);
	}

	public static function getColumnValueByName(array $rowData, array $colNames, $colName)
	{
		$index=array_search($colName, $colNames);
		return $index!==FALSE ? $rowData[$index] : '';
	}
	
	public static function getLastInsertId(PDO $db)
	{
		$mysql=defined('DB_NAME');
		return self::execAndReadInt(
			"SELECT ".($mysql ? 'last_insert_id()' : 'last_insert_rowid()'),
			0,
			null,
			$db
		);
	}
}
