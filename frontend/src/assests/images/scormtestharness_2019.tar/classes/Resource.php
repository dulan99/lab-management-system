<?php

require_once realpath(dirname(__FILE__)).'/DbUtils.php';

class Resource
{
	const SQL="select u.user_id as userId, r.resource_id as id, r.description, r.size, r.type, r.datetime, u.name as username
				from Resource r
				left join User u on u.user_id=r.user_id";
	
	public $id;
	public $userId;
	public $size;
	public $type;
	public $description;
	public $datetime;
	//pseudo
	public $username;
	
	public function __construct($setDateTime=true)
	{
		if ($setDateTime){
			$this->datetime=date('Y-m-d H:i');
		}
	}
	
	public function save()
	{
		//remove old
		DbUtils::exec(
			"delete from Resource where resource_id=:id", 
			array(
				'id' 		=> $this->id
			)
		);
		
		//(re)create
		$db=DbUtils::getConnection();
		DbUtils::exec(
			"insert into Resource (user_id, resource_id, description, size, type, datetime) values (:userId, :id, :desc, :size, :type, :datetime)", 
			array(
				'id' 		=> $this->id,
				'userId' 	=> $this->userId,
				'desc' 		=> $this->description,
				'size' 		=> $this->size,
				'type' 		=> $this->type,
				'datetime'  => $this->datetime
			), 
			$db
		);
	}
	
	public static function create($userId, $id, $description, $type, $size)
	{
		$r=new Resource();
		$r->id=$id;
		$r->userId=$userId;
		$r->description=$description;
		$r->type=$type;
		$r->size=$size;
		$r->save();
		return $r;
	}
	
	public static function getAllActiveTextResources()
	{
		return DBUtils::fetchAllObjects(
			self::SQL." where r.type='activetext' order by r.resource_id", 
			'Resource',
			null,
			null,
			array(false) //ctr args
		);
	}
	
	public static function getAllEbookResources()
	{
		return DBUtils::fetchAllObjects(
			self::SQL." where r.type='ebook' order by r.resource_id", 
			'Resource',
			null,
			null,
			array(false) //ctr args
		);
	}
	
	public static function getAllActivityResources()
	{
		return DBUtils::fetchAllObjects(
			self::SQL." where r.type!='ebook' and r.type!='other' and r.type!='activetext' order by r.resource_id", 
			'Resource', 
			null,
			null,
			array(false) //ctr args
		);
	}
	
	public static function getOtherResources()
	{
		return DBUtils::fetchAllObjects(
			self::SQL." where r.type='other' order by r.resource_id", 
			'Resource',
			null,
			null,
			array(false) //ctr args
		);
	}
	
	public static function getPath($resourceId)
	{
		while (strlen($resourceId) < 8)
		{
			$resourceId = '0' . $resourceId;
		}
			
		$path = '';
	
		for ($i = 2; $i <= 8; $i+=2)
		{
			$path .= 'r' . substr($resourceId, 0, $i) . '/';
		}
	
		return $path;
	}
}