<?php 

require_once realpath(dirname(__FILE__)).'/../classes/Action.php';
require_once realpath(dirname(__FILE__)).'/../classes/Resource.php';
require_once realpath(dirname(__FILE__)).'/../classes/AbstractLoggedInPage.php';

class Upload extends AbstractLoggedInPage
{
	protected $isWindows=false;
	protected $cygwinPath;
	
	protected $tmpName;
	protected $fileName;
	protected $resource;
	
	protected $stepNum=1;
	
	public function __construct()
	{
		parent::__construct();
		
		$this->cygwinPath = CYGWIN_BASH_EXE." --login -i -c ";
		
		if(!(strpos(strtolower(php_uname()), "windows")===false))
		{
			$this->isWindows = true;
		}
	}
	
	public function run()
	{
		if (array_key_exists('go', $_REQUEST))
		{
			$this->handleUpload();
		}
		else
		{
			$this->showForm();
		}
	}
	
	function showForm()
	{
		$this->loadComponent('upload-form.php');
	}
	
	function handleUpload()
	{
		$this->resource=new Resource();
		$this->resource->userId=$this->user->id;
		
		$this->loadComponent('upload-results-top.php');
		
		if ($this->validateAndExtract())
		{
			Action::log($this->user->id, "Uploaded file '{$this->fileName}' into resource id {$this->resource->id}");
			$this->resource->save();
		}

		$this->loadComponent('upload-results-bottom.php');
	}
	
	function logStep($title)
	{
		echo "<li>$title</li>\n";
		$this->stepNum++;
	}
	
	function error($msg)
	{
		echo "<p class=\"error\">$msg</p>\n";
	}
	
	function writeCommandOutput($op)
	{
		$op=join("\n", $op);
		
		?>
			<div class="consoleOutputWrapper">
				Cmd output <a href="#" class="showHideConsoleOutput">Show/hide details</a>:
				<div class="consoleOutput">
					<pre><?php echo $op ?></pre>
				</div>
			</div>
		<?php 
	}

	function validateAndExtract()
	{
		if (!array_key_exists('upload', $_FILES))
		{
			$this->showError("Uploaded file could not be found");
		}
		
		$info=$_FILES['upload'];
		
		if ($info['error']!=0)
		{
			if (strlen($info['name'])==0) $this->showError("Please select a file to upload");
			
			$this->showError("There was an error, code=: ".$info['error']." - possibly file too large?");
		}
		
		$this->fileName=$info['name'];
		$this->tmpName=$info['tmp_name'];
		$this->resource->id=intval(trim($this->getRequestValue('resourceId', 0)));
		if ($this->resource->id<=0) $this->showError("Resource id '".$_REQUEST['resourceId']."' should be an integer &gt;0");
		
		$this->resource->description=trim($this->getRequestValue('description', ''));
		if (strlen($this->resource->description)==0) $this->showError("Description is a required field");
		
		$this->resource->size=intval($info['size']);
		if ($this->resource->size<=10) $this->showError("File is very small. Please select a zip file with real content.");
		
		$this->resource->type=$this->getRequestValue('type', 'ebook');
		
		$resPath=Resource::getPath($this->resource->id); //ends with '/'
		
		$destPath='resources_www/'.$resPath.'current';
		$destFolder=getcwd().'/../'.$destPath;
		
		if (!$this->deleteResource($this->resource->id))
		{
			return false;
		}

		//create dir
		if (!file_exists($destFolder)){ //but first check that folder was removed in step above, if not, skip this step
			$this->logStep("Creating directory $destPath");
			if (!mkdir($destFolder, 0777, true))
			{
				$this->showError("Could not create folder $destPath");
			}
		}
		
		$this->logStep("Copying uploaded file {$this->fileName} to $destPath");
		$destFileName=$destFolder.'/'.$this->fileName;
		if (!move_uploaded_file($this->tmpName, $destFileName))
		{
			$this->showError("Could not copy uploaded file to $destFileName");
		}
		
		$extracted=false;
		if (preg_match("/\.zip$/i", $this->fileName))
		{
			//uncompress zip
			$this->logStep("Extracting zip {$this->fileName} to $destPath");
			
			$op=array();
			$retVal=false;
			if($this->isWindows)
			{	
				$strCmd = ($this->cygwinPath .' "'. addslashes(realpath(dirname(__FILE__))) .'/../utils/safe-unzip.sh '. addslashes($destFolder) .' '. $this->fileName .'"');
				exec($strCmd, $op, $retVal);
				if (intval($retVal)!=0)
				{
					$this->error("Failed");
					return false;
				}
			}
			else
			{
				exec("../utils/safe-unzip.sh $destFolder {$this->fileName}", $op, $retVal);
				if (intval($retVal)!=0)
				{
					$this->error("Failed");
					return false;
				}
			}
			$this->writeCommandOutput($op);
			$extracted=true;
		}
		
		$this->logStep("Summary");
		echo "File uploaded".($extracted?" and extracted to $resPath":"")."<br/>";
		echo "<br/>All Done. <a href=\"main.php\">Click here</a> to launch an ebook with activity/ies";
		
		return $extracted;
	}
	
	public function deleteResource($id, $showOutput=true)
	{
		$resPath=Resource::getPath($id); //ends with '/'
		
		$destPath='resources_www/'.$resPath.'current';
		$destFolder=realpath(dirname(__FILE__)).'/../'.$destPath;
		
		//remove old contents (NB this only permits files under resources_www to be deleted, due to prefixes above
		if ($showOutput) $this->logStep("Removing any existing contents in $destPath");
		if (file_exists($destFolder))
		{
			$op=array();
			$retVal=false;
			if($this->isWindows)
			{
				$strCmd = ($this->cygwinPath .' "'. addslashes(realpath(dirname(__FILE__))) .'/../utils/safe-delete.sh '. addslashes($destFolder) .'"');
				exec($strCmd, $op, $retVal);
				if (intval($retVal)!=0)
				{
					if ($showOutput) $this->error("Failed");
					return false;
				}
			}
			else
			{
				exec(realpath(dirname(__FILE__))."/../utils/safe-delete.sh $destFolder", $op, $retVal);
				if (intval($retVal)!=0)
				{
					if ($showOutput) $this->error("Failed");
					return false;
				}
			}
			if ($showOutput) $this->writeCommandOutput($op);
		}
		return true;
	}		
}
