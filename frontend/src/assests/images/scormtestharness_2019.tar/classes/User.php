<?php

require_once realpath(dirname(__FILE__)).'/DbUtils.php';

class User
{
	public $id;
	public $name;
	
	public static function getUserById($userId)
	{
		return DBUtils::fetchObject("select user_id as id, name from User where user_id=:id", 'User', array('id' => $userId));
	}
	
	public static function getUserByName($name)
	{
		return DbUtils::fetchObject('select user_id as id, name from User where name=:name', 'stdClass', array('name' => $name));
	}
	
	public function save()
	{
		if ($this->id>0)
		{
			//update
			DbUtils::exec(
				"update User set name=:name where user_id=:id", 
				array(
					'name' >$this->name, 
					'id' => $this->id
				)
			);
		}	
		else
		{
			//create
			$db=DbUtils::getConnection();
			DbUtils::exec(
				"insert into User (name) values (:name)", 
				array(
					'name' => $this->name
				), 
				$db
			);
			$this->id=DbUtils::getLastInsertId($db);
		}
	}
}