<?php

require_once realpath(dirname(__FILE__)).'/DbUtils.php';

class UserScorm
{
	public $id;
	public $allocationId;
	public $pupilId;
	public $fieldName;
	public $fieldValue;
	
	public static function clearByUserId($resourceId, $userId)
	{
		DBUtils::exec(
			"delete from user_scorm where user_id=:userId and resource_id=:resId",
			array(
				'userId' => $userId,
				'resId' => $resourceId
			)
		);
	}
	
	public static function getScormCount($resourceId, $userId)
	{
		return DBUtils::execAndReadInt(
			"select count(*) from user_scorm where user_id=:userId and resource_id=:resId",
			0,
			array(
				'userId' => $userId,
				'resId' => $resourceId
			)
		);
	}
	
	public static function setKeyValue($userId, $resourceId, $fieldName, $fieldValue)
	{
		DBUtils::exec(
			"DELETE FROM user_scorm
				where user_id=:userId
				and resource_id=:resourceId
				and field_name=:fieldName",
			array(
				'userId' 		=> $userId,
				'resourceId'	=> $resourceId,
				'fieldName' 	=> $fieldName
			)
		);
			
		//add new key-value pair
		DBUtils::exec(
			"insert into user_scorm
				(user_id, resource_id, field_name, field_value)
			values
				(:userId, :resourceId, :fieldName, :fieldValue)",
			array(
				'userId' 		=> $userId,
				'resourceId' 	=> $resourceId,
				'fieldName' 	=> $fieldName,
				'fieldValue' 	=> $fieldValue
			)
		);
	}
	
	public static function getAllForUserResource($userId, $resourceId)
	{
		return DBUtils::fetchAllObjects(
			"SELECT user_scorm_id as id, resource_id as allocationId, user_id as pupilId,
					field_name as fieldName, field_value as fieldValue
				FROM user_scorm
				WHERE user_id=:userId
				AND resource_id=:resourceId
				ORDER BY field_name",
			'UserScorm',
			array(
				'userId' 	 => $userId,
				'resourceId' => $resourceId
			)
		);
	}
}