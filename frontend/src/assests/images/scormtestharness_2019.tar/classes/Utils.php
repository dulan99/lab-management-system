<?php

require_once 'DbUtils.php';
require_once 'Action.php';
require_once 'User.php';

class Utils
{
	const COOKIE_NAME="TestHarness";
	
	public static function loginCheck()
	{
		$userId=self::getUserId();
		
		if ($userId==0)
		{
			header("Location: login.php");
			exit;
		}
		return User::getUserById($userId);
	}
	
	public static function getUser()
	{
		$userId=self::getUserId();
		
		return $userId!=0 ? DBUtils::fetchObject("select * from User where user_id=:id", 'stdClass', array('id' => $userId)) : null;
	}
	
	public static function getUserId()
	{
		$data=self::getCookieData();
		
		return $data!=null ? intval($data) : 0;
	}
	
	public static function setUserId($id)
	{
		self::setCookieData($id);
	}
	
	private static function getCookieData()
	{
		return array_key_exists(self::COOKIE_NAME, $_COOKIE) ? $_COOKIE[self::COOKIE_NAME] : null;
	}
	
	private static function setCookieData($data)
	{
		setcookie(self::COOKIE_NAME, $data, 0, '/');
	}
}