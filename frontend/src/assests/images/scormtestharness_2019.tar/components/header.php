<h1 class="main">SCORM Test Harness</h1>

<?php if ($this->showMenu){ ?>
	<div class="header">
		<div class="left">
			<?php if ($this->loggedIn){ ?>
				 <a href="/main.php">Launch ebook</a> | 
				 <a href="/upload.php">Upload resource</a> |
				 <a href="/resources.php">View uploaded resources</a> |
				 <a href="/logs.php">View logs</a> |
			 <?php } ?>  
			 <a href="/help.php" target="_blank">Help</a>
		 </div>
	 
	 	<?php if ($this->loggedIn){ ?>
		  	<div class="right">
		 		<a href="/clear-data.php">Clear all data</a> |
		 		user: <?php echo $this->user->name ?> |
		 		<a href="/login.php">Logout</a>
		 	</div>
	 	<?php } ?>
	 </div>
 <div class="clearboth">&nbsp;</div>
 <?php } ?>
 