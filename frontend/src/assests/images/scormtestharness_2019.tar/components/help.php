<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Test Harness | Help</title>
<link type="text/css" rel="stylesheet" href="/css/site.css">
</head>
<body>
<div id="compass"></div>
	
<div id="content">
<?php
	require_once 'header.php'; 
?>
	<h3>Help</h3>
	
	
	<h2>Logging in</h2>
	<p>Either select a user from the drop down list, of enter a name to create a new one.
	A password is not required</p>
	
	<h2>Basic operation:</h2>
	<ol>
		<li>Upload ebooks and activities using the 'Upload resource' link in the menu bar.</li>
		<li>Using the link 'Launch ebook', select the ebook to launch, along with activities for that ebook. 
		Each activity will be assigned sequentially to each hotspot in the ebook.</li>
	</ol>
	
	<h2>Advanced operation:</h2>
	<ul>
		<li>The 'Launch ebook' page can also accept custom ebook ids and activity ids. 
		To do this, select 'custom' from each list, and enter the ids in the text boxes provided</li>
		<li>If an ebook id or resource id is not found in the uploaded list, the Test Harness will try to load that id from the dev content server.
		This facility allows us to test a mixed bag of resources: some uploaded and some from the content server.</li>
		<li>Activity ids suffixed with '|c' are taken to be comprehension activities</li>
	</ul>
	
	<h2>Logging:</h2>
	<p>Most actions are logged. This helps when debugging, since we can see which resources were upload and when.</p>
	
	<h2>Resetting the Test Harness:</h2>
	<p>The system can be brought back to its inital state (no uploading resources, user or logs), by using the 
	form 'Clear all data'. You will be prompted for a security password.</p>
	
</div>
</body>
</html>