<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<?php 

$defaultActiveTextPlayerResourceId=240371;

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Test Harness | Platform</title>
<script type="text/javascript" src="js/lib/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="js/lib/purl.js"></script>
<script type="text/javascript" src="js/components/build/fn_messaging_bugclub.js"></script>
<script type="text/javascript">
MSG.Constants={
	resourcesUrl: '<?php echo RESOURCES_URL ?>',
	saveScormToServer: false,
	userId: <?php echo $this->user->id ?>

};
</script>
<script type="text/javascript" src="js/components/ebook-launcher/ebook-launcher.js"></script>
<link type="text/css" rel="stylesheet" href="/css/site.css">
</head>
<body>
<div id="compass"></div>
	
<div id="content">
	<?php
	require_once 'header.php'; 
	
	?>
	<h3>Ebook launcher</h3>
	
	<form id="launcherForm" name="launcherForm" action="#">
		
		<div class="box">
			<h4>1. Ebook</h4>
			<p>Select one resource</p>
			<div class="field">
				<select id="ebookId" name="ebookId" size="10">
					<?php foreach($this->ebookResources as $res){
						$kb=intval($res->size/1024);
						echo "<option value=\"{$res->id}\">{$res->id} - {$res->description} / {$kb}kb</option>";
					}?>
					<option value="-1">Custom</option>
				</select>
				<div id="customEbookIdBox">
					<p>Enter a resource id</p>
					<input type="text" id="customEbookId" name="customEbookId" />
				</div>
			</div>
		</div>
	
		<div class="box last">
			<h4>2. Activity(ies)</h4>
			<p>Select any number of resources (ctrl-click to select multiple):</p>
			<div class="field">
				<select id="activityIds" name="activityIds" size="10" multiple="multiple">
					<?php foreach($this->activityResources as $res){
						$kb=intval($res->size/1024);
						$type=(($res->type=='activity') ? 'Regular' : 'Comprehension');
						$val=$res->id . (($res->type=='comprehension') ? '|c' : '');
						echo "<option value=\"{$val}\">{$res->id} - {$res->description} / {$type} / ({$kb}kb)</option>";
					}?>
					<option value="-1">Custom</option>
				</select>
				<div id="customActivityIdsBox">
					<p>Enter a CSV list of activity ids</p>
					<input type="text" id="customActivityIds" name="customActivityIds" />
				</div>
			</div>
		</div>
		
		<hr/>
		
		<div class="box">
			<h4>3. ActiveText</h4>
			<p>Select the player:</p>
			<div class="field">
				<select id="activeTextPlayerResourceId" name="activeTextPlayerResourceId" size="10">
					<option value="<?php echo $defaultActiveTextPlayerResourceId ?>" selected="selected"><?php echo $defaultActiveTextPlayerResourceId ?> - Default</option>
					<?php foreach($this->activeTextResources as $res){
						echo "<option value=\"{$res->id}\">{$res->id} - {$res->description}</option>";
					}?>
				</select>
			</div>
		</div>
		
		<div class="box">
			<h4>4. Select mode</h4>
			<div class="field">
				<label for="teacher">Teacher</label><input type="radio" name="mode" value="teacher" checked="checked"/>
			</div>
			<div class="field">
				<label for="teacher">Pupil</label><input type="radio" name="mode" value="pupil"/>
			</div>
			<div class="scorm-info" style="display:none">
				<p>
					There are <span>x</span> record(s) for your user against this ebook. 
					<input type="button" id="clear-scorm" value="Clear"/>
					<input type="button" id="refresh-scorm-count" value="Refresh"/>
				</p>
			</div>
		</div>
		
		<div class="box last">
			<h4>5. Launch ebook and activities</h4>
			<p>When done, click 'go'</p>
			<div class="field">
				<p><input type="submit" value="Go!"/></p>
			</div>
		</div>
		
</form>
</div>
</body>
</html>