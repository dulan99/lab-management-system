<html>

<head>
<link type="text/css" rel="stylesheet" href="/css/site.css">
</head>

<body>
<div id="compass"></div>
	
<div id="content">
	<?php
	require_once 'header.php'; 
	
	?>
	<h2>Login</h2>
	<div class="loginWrapper">
		<form name="login" id="login" method="post">
			<div class="field">
				<label for="username">New user:</label>
				<input type="text" id="name" name="name" />
			</div>
			
			<?php if (count($this->allUsers)>0){ ?>
				<div class="field">
					<label for="username">Existing user:</label>
					<select id="user_id" name="user_id">
						<option value="0">Please select...</option>
						
					<?php 
						foreach($this->allUsers as $userObj){
							echo "<option value=\"{$userObj->user_id}\">{$userObj->name}</option>\n";
						}	 
						?>
					</select>
				</div>
			<?php } ?>
			
			<div class="field">
				<input type="submit" id="go" name="go" value="Login"/>
			</div>
		</form>
	</div>
</div>

</body>

</html>