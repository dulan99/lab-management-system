<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Test Harness | Platform</title>
<link type="text/css" rel="stylesheet" href="/css/site.css">
</head>
<body>
<div id="compass"></div>
	
<div id="content">
	<?php
	require_once 'header.php'; 
	
	?>
	<h3>Resource uploader</h3>
	<p>Upload resources (.zip files will be uncompressed):<p>
	<form id="uploadForm" name="uploadForm" action="upload.php" method="post" enctype="multipart/form-data">
	
	<div class="field">
		<label for="resourceId">Resource ID: </label>
		<input type="text" id="resourceId" name="resourceId" />
	</div>
	<div class="field">
		<label for="description">Description </label>
		<input type="text" id="description" name="description" size="50"/>
	</div>
	<div class="field">
		<label for="type">Type</label>
		<select id="type" name="type">
			<option value="activity">Activity (non-comprehension)</option>
			<option value="comprehension">Activity (Comprehension)</option>
			<option value="ebook">Ebook</option>
			<option value="activetext">ActiveText player</option>
			<option value="other">Other</option>
		</select>
	</div>
	
	<div class="field">
		<label for="upload">File</label>
		<input type="file" id="upload" name="upload" />
	</div>
		
	<div class="field">
		<input type="submit" id="go" name="go" value="Go!"/>
	</div>
	</form>
</div>
</body>
</html>