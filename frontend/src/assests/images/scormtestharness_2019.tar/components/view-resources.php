<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Test Harness | Platform</title>
<link type="text/css" rel="stylesheet" href="/css/site.css">
</head>
<body>
<div id="compass"></div>
	
<div id="content">
	
	<?php
	require_once 'header.php'; 
	
	?>
	<h3>Uploaded Resources</h3>
	
		<table>
			<thead>
				<tr>
					<th>Resource ID</th>
					<th>Type</th>
					<th>Desciption</th>
					<th>Uploaded by</th>
					<th>When</th>
				</tr>
			</thead>
			<tbody>
			<?php 
				foreach($this->ebookResources as $res){
					$kb=intval($res->size/1024);
			?>
				<tr>
					<td><?php echo $res->id ?></td>
					<td>Ebook</td>
					<td><?php echo $res->description ?></td>
					<td><?php echo $res->username ?></td>
					<td><?php echo $res->datetime ?></td>
				</tr>
			<?php } ?>
	
			<?php foreach($this->activityResources as $res){
					$kb=intval($res->size/1024);
				?>
				<tr>
					<td><?php echo $res->id ?></td>
					<td>Activity (<?php echo $res->type ?>)</td>
					<td><?php echo $res->description ?></td>
					<td><?php echo $res->username ?></td>
					<td><?php echo $res->datetime ?></td>
				</tr>
				<?php } ?>
				
				<?php foreach($this->otherResources as $res){
					$kb=intval($res->size/1024);
				?>
				<tr>
					<td><?php echo $res->id ?></td>
					<td>Activity (<?php echo $res->type ?>)</td>
					<td><?php echo $res->description ?></td>
					<td><?php echo $res->username ?></td>
					<td><?php echo $res->datetime ?></td>
				</tr>
				<?php } ?>
				
				<?php foreach($this->activeTextResources as $res){
					$kb=intval($res->size/1024);
				?>
				<tr>
					<td><?php echo $res->id ?></td>
					<td>ActiveText player</td>
					<td><?php echo $res->description ?></td>
					<td><?php echo $res->username ?></td>
					<td><?php echo $res->datetime ?></td>
				</tr>
				<?php } ?>
				
			</tbody>
		</table>
</div>
</body>
</html>