<?php
define("RESOURCES_URL", 'http://resources.scormtestharness.opsworks.alp-nightly.alp.pearson-intl.com');
define('CYGWIN_BASH_EXE', "c:\\cygwin64\\bin\\bash.exe");

define('DB_HOST', 'alpnightlyrds.cd8dd3ricv1t.eu-west-1.rds.amazonaws.com');
define('DB_PORT', 3306);
define('DB_NAME', 'test_harness');
define('DB_USERNAME', 'PhubsDevApp');
define('DB_PASSWORD', 'p3@primaryhubsapp');
?>
