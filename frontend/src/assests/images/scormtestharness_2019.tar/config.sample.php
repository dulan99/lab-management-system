<?php 
define("RESOURCES_URL", 'http://resources.scormtestharness.nightly.alp.hosts.pearson-intl.net');
define('CYGWIN_BASH_EXE', "c:\\cygwin64\\bin\\bash.exe");

define('DB_HOST', 'db-master.nightly.primaryhubs.uk.services.pearson-intl.net');
define('DB_PORT', 3306);
define('DB_NAME', 'test_harness');
define('DB_USERNAME', 'PhubsDevApp');
define('DB_PASSWORD', 'p3@primaryhubsapp');
?>
