drop table if exists User;
drop table if exists Action;
drop table if exists Resource;

CREATE TABLE User (user_id INTEGER PRIMARY KEY AUTO_INCREMENT, name varchar(50));
CREATE TABLE Action (action_id INTEGER PRIMARY KEY AUTO_INCREMENT, user_id INTEGER, message varchar(255), datetime timestamp);
CREATE TABLE Resource (resource_id INTEGER PRIMARY KEY, user_id INTEGER, type TEXT, size INTEGER, description varchar(255), datetime timestamp);