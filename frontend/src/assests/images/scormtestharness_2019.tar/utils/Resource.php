<?php

class Resource
{
	public static function getPath($resourceId)
	{
		while (strlen($resourceId) < 8)
		{
			$resourceId = '0' . $resourceId;
		}
			
		$path = '';
	
		for ($i = 2; $i <= 8; $i+=2)
		{
			$path .= 'r' . substr($resourceId, 0, $i) . '/';
		}
		
		return $path;
	}
	public static function getPathDelete($resourceId)
	{
		while (strlen($resourceId) < 8)
		{
			$resourceId = '0' . $resourceId;
		}
			
		$path = '';
	
		for ($i = 2; $i <= 8; $i+=2)
		{
			$path .= '/r' . substr($resourceId, 0, $i);
		}
		
		return $path;
	}
}
