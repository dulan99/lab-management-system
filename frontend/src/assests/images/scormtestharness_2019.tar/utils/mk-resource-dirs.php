<?php
require_once '../classes/Resource.php';

$resourceIds=array(
	193773, 193841, 193838
);

foreach($resourceIds as $resourceId)
{
	$path='../resources_www/'.Resource::getPath($resourceId).'';
	
	echo "$path\n";
	
	if (!file_exists($path))
	{
		mkdir($path, 0777, true);
	}
}
