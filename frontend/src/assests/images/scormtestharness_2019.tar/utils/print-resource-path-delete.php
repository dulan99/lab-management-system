<?php
require_once realpath(dirname(__FILE__)).'/../classes/Resource.php';



if (count($argv)!=2)
{
	die ("\n\tSyntax: ".$argv[0]." [resource-id]\n\n");
}

$resourceId=intval($argv[1]);
echo Resource::getPathDelete($resourceId)."\n";
