<?php
require_once '../classes/Resource.php';



if (count($argv)!=2)
{
	die ("\n\tSyntax: ".$argv[0]." [resource-id]\n\n");
}

$resourceId=intval($argv[1]);
echo '/'.Resource::getPath($resourceId).'current'."\n";
