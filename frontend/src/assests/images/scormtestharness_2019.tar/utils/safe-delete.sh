#!/bin/bash

#safe-ish anyway: will only delete under a folder 'resources_www'

if [ $# -ne 1 ]
then
  exit $E_BADARGS
fi

FILE=$1

if [[ "$FILE" != */resources_www/* ]]
then
  echo "Filepath does not contain resources_www, not deleting";
  exit $E_BADARGS
fi

if [ -d $FILE ]; then
	echo "Recursively deleting $FILE"
	rm -rf $FILE
fi 

exit 0;