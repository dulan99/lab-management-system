#!/bin/bash

if [ $# -ne 2 ]
then
  echo "Syntax: $0 [destFolder] [name]"
  exit $E_BADARGS
fi

FOLDER=$1
FILE=$2

if [ ! -d $FOLDER ]; then
	echo $FOLDER is not a directory
	exit $E_BADARGS
fi

cd $FOLDER;
if [ ! -f $FILE ]; then
	echo `pwd`
	echo $FILE is not a file
	exit $E_BADARGS
fi

#extract (overwrite too)
unzip -o $FILE

echo done

exit 0;