#!/bin/bash

find ../resources_www -type d -exec chmod a+rwx {} \;
find ../resources_www -type f -exec chmod a+rw {} \;