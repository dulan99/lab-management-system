<?php
require_once '../classes/Resource.php';

$resourceIds=array(
	900001,900002,900003,900004,900005,
	900101,900102,900103,
	900110,900111,900112,900113,900114,900115,900116,900117,900118,900119,900120,900121,900122,900123,900124,900125,900126,900127,
	900201,900202,
	999001,999101,
	999201
);

foreach($resourceIds as $resourceId)
{
	$path='../resources_www/'.Resource::getPath($resourceId).'';
	
	echo "$path\n";
}
