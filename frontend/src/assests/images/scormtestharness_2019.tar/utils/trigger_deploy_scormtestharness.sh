# Deploy Build
deploy=`s3cmd ls s3://primary-hubs/nightly/ | grep dev_scormtestharness_build -q && echo "ready"`
{
if [ -z "$deploy" ]; then
echo `date`
echo "No new build to deploy"
exit

fi

if [ $deploy == "ready" ]; then

s3cmd get s3://primary-hubs/nightly/dev_scormtestharness_build
echo "Subject: Deploy scorm test harness log from ALP Dev Server - `date`"
BUILD_NUMBER=`cat dev_scormtestharness_build`

echo "copying exiting config to /tmp/scormtestharness-config.php"
cp config.php /tmp/scormtestharness-config.php


s3cmd get s3://primary-hubs/nightly/scorm-testharness-$BUILD_NUMBER.tgz

tar xzvf scorm-testharness-$BUILD_NUMBER.tgz


chmod -R 775 /home/webapps/scormtestharness/builds/
chmod -R 775 /home/webapps/scormtestharness/classes/
chmod -R 775 /home/webapps/scormtestharness/components/

chmod -R 775 /home/webapps/scormtestharness/resources_www/
chmod -R 775 /home/webapps/scormtestharness/utils/
chmod -R 775 /home/webapps/scormtestharness/www/


chown -R apache:apache /home/webapps/scormtestharness


echo "Latest build - `date`" > /home/webapps/scormtestharness/www/build.txt

rm -rf /home/webapps/scormtestharness/scorm-testharness-$BUILD_NUMBER.tgz
rm /home/webapps/scormtestharness/dev_scormtestharness_build

s3cmd del s3://primary-hubs/nightly/dev_scormtestharness_build > /dev/null
s3cmd del s3://primary-hubs/nightly/scorm-testharness-$BUILD_NUMBER.tgz > /dev/null



fi
} > /home/webapps/scormtestharness/scormtestharness_build.log


mail -s 'alp nightly scorm test harness deployment triggered' ross.purchase@pearson.com caroline.briggs@pearson.com  < /home/webapps/scormtestharness/scormtestharness_build.log