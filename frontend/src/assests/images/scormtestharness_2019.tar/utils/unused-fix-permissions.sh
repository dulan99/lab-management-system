#!/bin/bash

#fix permissions
sudo chown -R pearson:apache ~/websites/scormtestharness-primaryhubs/
find ~/websites/scormtestharness-primaryhubs/ -type d -exec chmod gu+rwx {} \;
find ~/websites/scormtestharness-primaryhubs/ -type f -exec chmod gu+rw {} \;
