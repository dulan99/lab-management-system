#!/bin/bash

#deploy to web6

BASEDIR=$(dirname $0)

#fix permissions
echo "Fixing permissions before deployment" 
ssh pearson@web6 "chmod +x ~/websites/scormtestharness-primaryhubs/utils/fix-permissions.sh"
ssh -t pearson@web6 "~/websites/scormtestharness-primaryhubs/utils/fix-permissions.sh"

#copy files
echo "Copying files"
echo -e "\tSyncing test harness"
rsync -av --exclude="config.php" --exclude="resources_www/r00" ${BASEDIR}/../../scorm-test-harness/ pearson@web6:~/websites/scormtestharness-primaryhubs/ 2>&1 | tee rsync.log

#fix permissions
echo "Fixing permissions after deployment"
ssh pearson@web6 "chmod +x ~/websites/scormtestharness-primaryhubs/utils/fix-permissions.sh"
ssh -t pearson@web6 "~/websites/scormtestharness-primaryhubs/utils/fix-permissions.sh"
