<?php 

require_once realpath(dirname(__FILE__)).'/../classes/Action.php';
require_once realpath(dirname(__FILE__)).'/../classes/Resource.php';
require_once realpath(dirname(__FILE__)).'/../classes/AbstractLoggedInPage.php';
require_once realpath(dirname(__FILE__)).'/../classes/Upload.php';

class ClearData extends AbstractLoggedInPage
{
	const PASSWORD="resetHubs913";
	
	public function __construct()
	{
		parent::__construct();
	}
	
	public function run()
	{
		if (array_key_exists('go', $_REQUEST))
		{
			$this->clearData();
		}
		else
		{
			$this->showForm();
		}
	}
	
	function showForm()
	{
		$this->loadComponent('clear-data-form.php');
	}
	
	function clearData()
	{
		$pwd=$this->getRequestValue('password');
		
		if ($pwd!=self::PASSWORD)
		{
			$this->loadComponent('clear-data-pwd-error.php');
			return;
		}
		
		//clear all uploaded resources
		$upload=new Upload();
		
		$ebooks=Resource::getAllEbookResources();
		$activities=Resource::getAllActivityResources();
		foreach($ebooks as $ebook)
		{
			$upload->deleteResource($ebook->id);
		}
		foreach($activities as $activity)
		{
			$upload->deleteResource($activity->id);
		}
		
		//remove all data...
		foreach(array('resource', 'action', 'user') as $tableName)
		{
			DBUtils::exec("delete from $tableName");
		}
		
		Utils::setUserId(0);
		header("Location: /login.php");
	}
}

AbstractPage::runPage('ClearData');