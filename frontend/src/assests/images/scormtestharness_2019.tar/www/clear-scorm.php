<?php 

require_once realpath(dirname(__FILE__)).'/../classes/AbstractLoggedInPage.php';
require_once realpath(dirname(__FILE__)).'/../classes/Resource.php';
require_once realpath(dirname(__FILE__)).'/../classes/Action.php';
require_once realpath(dirname(__FILE__)).'/../classes/UserScorm.php';

class ClearScorm extends AbstractLoggedInPage 
{
	function __construct()
	{
		parent::__construct();
	}
	
	function run()
	{
		$ok=false;
		
		$ebookId=$this->getRequestValue('ebookId');
		
		if ($ebookId>0)
		{
			UserScorm::clearByUserId($ebookId, $this->user->id);
			
			Action::log($this->user->id, "Clearing SCORM data for ebook '$ebookId'");
			
			$ok=true;
		}
		header("Content-Type: text/json");
		echo(json_encode(array(
			'ok'=> ($ok?"true":"false")
		)));
	}
}

AbstractPage::runPage('ClearScorm');