<?php 
define("RESOURCES_URL", 'http://resources.scormtestharness.primaryhubs.local');
?>
