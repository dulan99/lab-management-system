<?php

// If you want do save/load SCORM data, this is the place to do it.

//return that the action was successful.
header("Content-type: text/javascript");

$callbackFn=$_REQUEST['callback'];

$data=array(
	'ok'=>"true",
	'allowed'=>'true',
	'uid'=>123
);

echo "{$callbackFn}(".json_encode($data).");";