<?php

// If you want do save/load SCORM data, this is the place to do it.

require_once realpath(dirname(__FILE__)).'/../classes/AbstractLoggedInPage.php';
require_once realpath(dirname(__FILE__)).'/../classes/Resource.php';
require_once realpath(dirname(__FILE__)).'/../classes/Action.php';
require_once realpath(dirname(__FILE__)).'/../classes/UserScorm.php';

class ScormHandler extends AbstractLoggedInPage
{
	protected $jsonp=false;
	//scorm params
	protected $action=null;
	protected $allocationId=-1;
	protected $pupilId=-1;
	protected $data=null;
	
	public function __construct($jsonp=true)
	{
		$this->jsonp=$jsonp;
	}

	function run()
	{
		$this->action		= self::getRequestValue('action');
		$this->allocationId	= self::getRequestValue('allocationId');
		$this->pupilId		= self::getRequestValue('pupilId');
		$this->data			= self::getRequestValue('data');
		
		$this->data = (strlen($this->data)>0 ? json_decode($this->data) : array());
		
		switch($this->action)
		{
			case "bulkGet":
	
				$items=UserScorm::getAllForUserResource($this->pupilId, $this->allocationId);
				if ($items==null)
				{
					$items=array();
				}
				$this->data=array();
				foreach($items as $item)
				{
					$this->data[$item->fieldName]=$item->fieldValue;
				}
				$this->returnData($this->data);
				break;
			case "bulkSet":
				foreach($this->data as $fieldName=>$fieldValue)
				{	
					UserScorm::setKeyValue($this->pupilId, $this->allocationId, $fieldName, $fieldValue);
				}
				
				$this->returnData("true");
				break;
		
			default:
				error_log("SCORM call: Unknown action '{$this->action}', pupilId={$this->pupilId}, allocationId={$this->allocationId}");
				break;
		}
	}
	
	protected function returnData($data)
	{
		$this->_return($data);
	}
	
	protected function returnError($data)
	{
		$this->_return($data, true /*error*/);
	}
	
	protected function _return($data, $isError=false)
	{
		if ($this->jsonp)
		{
			//jsonp mode
			$callback = $_GET["callback"];
				
			$resp = array(
				'a' 	=> $this->action,
				'resp' 	=> $data,
				'error' => ($isError ? 'true' : 'false')
			);
				
			header("Content-type: text/javascript");
			echo $callback . '(' . json_encode($resp). ');';
		}
		else
		{
			//not jsonp mode
			header("Content-type: application/json");
			echo json_encode($data);
		}
	}
}

AbstractPage::runPage('ScormHandler');
