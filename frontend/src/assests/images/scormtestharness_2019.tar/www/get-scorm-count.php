<?php 

require_once realpath(dirname(__FILE__)).'/../classes/AbstractLoggedInPage.php';
require_once realpath(dirname(__FILE__)).'/../classes/Resource.php';
require_once realpath(dirname(__FILE__)).'/../classes/Action.php';
require_once realpath(dirname(__FILE__)).'/../classes/UserScorm.php';

class GetScormCount extends AbstractLoggedInPage 
{
	function __construct()
	{
		parent::__construct();
	}
	
	function run()
	{
		$ok=false;
		$count=0;
		
		$ebookId=$this->getRequestValue('ebookId');
		
		if ($ebookId>0)
		{
			$count=UserScorm::getScormCount($ebookId, $this->user->id);
			
			$ok=true;
		}
		header("Content-Type: text/json");
		echo(json_encode(array(
			'ok'=> ($ok?"true":"false"),
			'count' => $count
		)));
	}
}

AbstractPage::runPage('GetScormCount');