<?php 

require_once realpath(dirname(__FILE__)).'/../classes/AbstractLoggedInPage.php';
require_once realpath(dirname(__FILE__)).'/../classes/Resource.php';

class Help extends AbstractLoggedInPage 
{
	function __construct()
	{
		parent::__construct();
		
		$this->showMenu=false;
	}
	
	function run()
	{
		$this->loadComponent('help.php');
	}
}

AbstractPage::runPage('Help');