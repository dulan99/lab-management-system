/*jslint regexp: true, nomen: true, browser: true, continue: true, unparam: true, sloppy: true, eqeq: true, sub: true, vars: true, white: true, forin: true, newcap: true, plusplus: true, maxerr: 50, indent: 4 */
/*global PLAYER:true,alert,console,$,jQuery,swfobject,MSG */

MSG.Launcher=MSG.declareClass({
    ebookId: 0,
    activityCsvIds: '',
    mode: 'teacher',
    
    init: function()
    {
        var _this=this;
        $('#ebookId').on('change', function(ev){
            _this.ebookIdChanged(ev);
        });
        
        $('#activityIds').on('change', function(ev){
            _this.activityIdsChanged(ev);
        });
        
        $('#launcherForm').on('change', '[name=mode]', function(){
            if($(this).is(':checked')){
                _this.updateInfoPanel();
            }
        });
        
        $('#clear-scorm').on('click', function(){
           _this.clearScorm(); 
        });
        
        $('#refresh-scorm-count').on('click', function(){
            _this.updateScormCount();  
         });
        
        $('#launcherForm').on('submit', function(ev){
            try{
                _this.formSubmitted();
            }catch(ex)
            {
                _this.log(ex);
            }
            
            return false;
        });
    },
    
    updateInfoPanel: function()
    {
        var mode=$("input:radio[name=mode]:checked").val();
        switch(mode)
        {
        case 'pupil':
            this.updateScormCount();
            break;
        case 'teacher':
        default:
            $('div.scorm-info').hide();
            break;    
        }
        this.mode=mode;
    },
    
    updateScormCount: function()
    {
        var ebookId=this.getEbookId();
        if (ebookId==0){
//            $('input:radio[name=mode]').filter('[value=teacher]').prop('checked', true);
            $('div.scorm-info').show();
            return;
        }
        
        $.ajax({
            url: '/get-scorm-count.php',
            method: 'post',
            data: {
                ebookId: ebookId
            }
        }).success(function(data)
        {
            $('div.scorm-info span').html(data.count);
            
            if (data.count>0)
            {
                $('#clear-scorm').show();
            }
            else
            {
                $('#clear-scorm').hide();
            }
            $('div.scorm-info').show();
                        
        }).error(function(msg)
        {
            _this.log(msg);
        });
    },
    
    clearScorm: function()
    {
        var _this=this;
        
        var ebookId=this.getEbookId();
        if (ebookId==0) return;
        
        $.ajax({
            url: '/clear-scorm.php',
            method: 'post',
            data: {
                ebookId: ebookId
            }
        }).success(function(){
            _this.updateScormCount();  
        });
    },
    
    ebookIdChanged: function(ev)
    {
        this.showHideCustomBox('#ebookId', '#customEbookIdBox');
        this.updateInfoPanel();
    },
    
    activityIdsChanged: function(ev)
    {
        this.showHideCustomBox('#activityIds', '#customActivityIdsBox');
    },
    
    parseInt: function(str)
    {
        var str=$.trim(str);
        var i=str.length>0 ? parseInt(str,10) : 0;
        return !isNaN(i) ? i : 0; 
    },
    
    isCustom: function(id)
    {
        return this.parseInt($(id).val())==-1;
    },
    
    showHideCustomBox: function(dropDownId, customBoxId)
    {
        var showCustomBlock=this.isCustom(dropDownId);
        if (showCustomBlock) 
        {
            //show custom area
            $(customBoxId).show();
        }
        else
        {
            //hide custom area
            $(customBoxId).hide();
        }
    },
    
    formSubmitted: function()
    {
        var _this=this;
        
        if (this.validateFields())
        {
            var activityIdsArr=_this.activityCsvIds.split(',');
            var activityTypesArr=new Array(activityIdsArr.length);
            var i;
            for (i=0; i<activityIdsArr.length; ++i)
            {
                var activityIdStr=activityIdsArr[i];
                
                var parts=activityIdStr.split('|');
                var activityId=$.trim(parts[0]);
                var activityType=(parts.length>1 ? $.trim(parts[1]) : 'r'); //r=regular, c=comprehension
                
                activityIdsArr[i]=activityId;
                activityTypesArr[i]=activityType;
            }
            
            var url=$.url();
            var port=url.attr('port');
            var scormUri=url.attr('protocol')+'://'+url.attr('host')+(port && port.length>0 ? ':'+port : '')+'/epub-scorm-handler.php';
            
            this.launchEbook(
                _this.ebookId, 
                activityIdsArr,
                activityTypesArr,
                _this.mode=='pupil', //isPupil
                _this.mode=='pupil', //true, //useScorm
                _this.mode=='pupil' ? _this.ebookId : 0, //allocationId
                MSG.Constants.userId,
                scormUri, 
                MSG.Constants.resourcesUrl, 
                parseInt($('#activeTextPlayerResourceId').val(),10)
            );
        }
    },
    
    getEbookId: function(showErrors)
    {
        var ebookId=0;
        if (this.isCustom('#ebookId'))
        {
            //custom ebook id
            var customStr=$.trim($('#customEbookId').val());
            if (customStr.length==0)
            {
                if (showErrors) alert('Please enter a value for the custom ebook id');
                return 0;
            }
            ebookId=this.parseInt(customStr);
            if (ebookId==0){
                if (showErrors) alert("Custom ebook id '"+customStr+"' needs to be an integer");
                return 0;
            }
        }
        else
        {
            //ebook id from list
            var customStr=$.trim($('#ebookId').val());
            ebookId=this.parseInt(customStr);
            if (ebookId==0){
                if (showErrors) alert('Please select an ebook from the list');
                return 0;
            }
        }
        return ebookId;
    },
    
    validateFields: function()
    {
        var _this=this;
        
        //find ebookId
        var ebookId=this.getEbookId(true);
        if (ebookId==0) return false;
        
        //find activityCsvIds
        var activityCsvIds='';
        if (this.isCustom('#activityIds'))
        {
            //custom activity ids, should be of type 123,456|c,789,...
            var customActivityCsvIdsStr=$.trim($('#customActivityIds').val());
            
            if (customActivityCsvIdsStr.length==0)
            {
                alert("Please enter a CSV list for the custom activity ids. You can append '|c' to comprehension ones, like this: 123456,456789|c,234567");
                return false;
            }
            
            //split and check each: either: 123 or 123|c
            var valid=true;
            
            $.each($.trim(customActivityCsvIdsStr).split(','), function(index, str){
                var activityId='';
                var typeStr='';
                
                if  (str.indexOf('|')>0)
                {
                    var bits=$.trim(str).split('|');
                    activityId=_this.parseInt(bits.length>0 ? bits[0] : '');
                    if (activityId==0){
                        alert('Activity '+bits+' is not recognised. Format is either 123456 or 123456|c (for comprehension activities)');
                        valid=false;
                        return;
                    }
                    typeStr=bits.length>1 ? bits[1] : '';
                }
                else
                {
                    activityId=_this.parseInt(str);
                    if (activityId==0)
                    {
                        alert("Custom activity id '"+str+"' needs to be an integer, or an integer suffixed with '|c");
                        valid=false;
                        return;
                    }
                }
                if (activityCsvIds.length>0) activityCsvIds+=',';
                activityCsvIds+=activityId+(typeStr.length>0 ? '|'+typeStr : '');
            });
            if (!valid) return false;
        }
        else
        {
            //activity ids from list
            var activityIdsArr=$('#activityIds').val();
            if (activityIdsArr==null || activityIdsArr.length==0)
            {
                alert('Please select one or more activity ids');
                return false;
            }
            $.each(activityIdsArr, function(index, activityIdStr){
                if (activityCsvIds.length>0) activityCsvIds+=',';
                activityCsvIds+=activityIdStr;
            });
        }
        
        _this.ebookId=ebookId;
        _this.activityCsvIds=activityCsvIds;
        
        return true;
    },

    
    launchEbook: function(resourceId, activityIdsArr, activityTypesArr, isPupil, useScorm, allocationId, userId, scormUri, resourcesUrl, activeTextPlayerResourceId)
    {
        var _this=this;
        
//        var thisUrl=$.url();
//        var port=thisUrl.attr('port');
//        var schemePortAndHost = thisUrl.attr('protocol')+'://'+thisUrl.attr('host')+(port && port.length>0 ? ':'+port : '');
        
//        var scormChildScriptSrc      = schemePortAndHost + '/js/build/scorm-merged-child.js';
//        var scormControllerScriptSrc = schemePortAndHost + '/js/build/scorm-merged-controller.js';
        
        var opts={
            'resourceId'                : resourceId,
            'activeTextPlayerResourceId': activeTextPlayerResourceId,
            'activityIds'               : activityIdsArr.join(','),
            'activityTypes'             : activityTypesArr.join(','),
            'isTestHarness'				: true,
            'isPupil'                   : isPupil,
            'useScorm'                  : useScorm,
            'allocationId'              : allocationId,
            'userId'                    : userId,
            'scormUri'                  : scormUri //,
//            'scormChildScriptSrc'       : scormChildScriptSrc,
//            'scormControllerScriptSrc'  : scormControllerScriptSrc
        };
        var url=resourcesUrl+'/epub/platform-player/index.html?dummy=1';
        $.each(opts, function(key, val){
            url+='&'+key+'='+val;
        });
        
        try{
            //log that ebook is being launched
            $.ajax({
               url: '/log-launch-resource.php',
               data: {
                   ebookId: _this.ebookId,
                   activityCsvIds: _this.activityCsvIds 
               }
            });
        }catch(ex){
            _this.log(ex);
        }
        
        
        var win=window.open(url, 'MSGEPubWin');
        try{
            $(win).focus();
        }catch(e){} //try/catch for IE
    },
    
    log: function(o){
        if (typeof(console)!="undefined" && console.debug) console.debug(o);
    }
});

$(document).ready(function(){
    var launcher=new MSG.Launcher();
});