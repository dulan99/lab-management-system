

$(document).ready(function(){
   
    $('.showHideConsoleOutput').on('click', function(){
        var divE=$(this).next('.consoleOutput');
        if (divE.length>0)
        {
            divE=$(divE[0]);
            
            if (divE.is(":visible"))
            {
                divE.hide();
            }
            else
            {
                divE.show();            
            }
        }
    });
});