<?php 

require_once realpath(dirname(__FILE__)).'/../classes/AbstractLoggedInPage.php';
require_once realpath(dirname(__FILE__)).'/../classes/Resource.php';
require_once realpath(dirname(__FILE__)).'/../classes/Action.php';

class LogLaunchResource extends AbstractLoggedInPage 
{
	function __construct()
	{
		parent::__construct();
	}
	
	function run()
	{
		$ebookId=$this->getRequestValue('ebookId');
		$activityCsvIds=$this->getRequestValue('activityCsvIds');
		
		Action::log($this->user->id, "Launching ebook '$ebookId' with activity/ies '$activityCsvIds'");
	}
}

AbstractPage::runPage('LogLaunchResource');