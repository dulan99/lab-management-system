<?php

require_once '../classes/AbstractPage.php';

class Login extends AbstractPage
{
	private $user=null;
	
	protected $allUsers=array();
	
	function __construct()
	{
		parent::__construct();
	}

	function run()
	{
		$user_id = intval($this->getRequestValue('user_id', 0));
		$name	 = trim($this->getRequestValue('name', ''));
		
		if ($user_id>0)
		{
			//submitted with selected user id
			$user=User::getUserById($user_id);
			
			if ($user!=null)
			{
				$this->setUserAndGoToHomepage($user_id);
			}
			else
			{
				$this->showError("User $name could not be created.");
			}
		}
		else if (strlen($name)>0)
		{
			//submitted with new username
			
			//check if user already exists
			$user=User::getUserByName($name);
			
			if ($user==null)
			{
				//create user
				$user=new User();
				$user->name=$name;
				$user->save();
				
				Action::log(0, "User '$name' created");
			}		
			//load user
			$user=User::getUserByName($name);
			
			if ($user!=null)
			{
				$this->setUserAndGoToHomepage($user->id);
			}
			else
			{
				$this->showError("User $name could not be created.");
			}
		}
		else
		{
			$this->allUsers=DbUtils::fetchAllObjects('select user_id, name from User order by name');
			
			$this->loadComponent('login-form.php');
		}
	}
}

AbstractPage::runPage('Login');