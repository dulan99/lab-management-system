<?php

require_once '../classes/AbstractLoggedInPage.php';
require_once '../classes/Action.php';

class Logs extends AbstractLoggedInPage
{
	protected $actions=array();
	
	function __construct()
	{
		parent::__construct();
	}

	function run()
	{
		$this->actions=Action::getAllActions();
		$this->loadComponent('view-logs.php');
	}
}

AbstractPage::runPage('Logs');