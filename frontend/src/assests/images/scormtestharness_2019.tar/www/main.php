<?php 

require_once realpath(dirname(__FILE__)).'/../classes/AbstractLoggedInPage.php';
require_once realpath(dirname(__FILE__)).'/../classes/Resource.php';

class Main extends AbstractLoggedInPage 
{
	protected $ebookResources	   = array();
	protected $activityResources   = array();
	protected $activeTextResources = array();
	
	function __construct()
	{
		parent::__construct();
	}
	
	function run()
	{
		$this->ebookResources	   = Resource::getAllEbookResources();
		$this->activityResources   = Resource::getAllActivityResources();
		$this->activeTextResources = Resource::getAllActiveTextResources();
		
		$this->loadComponent('launch-resource.php');
	}
}

AbstractPage::runPage('Main');