
function unloadHandler(ev)
{
    console.log("child page hide");
    
    ev.returnValue='';
}

$(document).ready(function(){
   $(window).on("pagehide", unloadHandler).on("unbeforeload", unloadHandler);
   
   $('#doThing').on("click", function(){
      location.reload(); 
   });
});