<?php 

require_once realpath(dirname(__FILE__)).'/../classes/AbstractLoggedInPage.php';
require_once realpath(dirname(__FILE__)).'/../classes/Resource.php';

class Main extends AbstractLoggedInPage 
{
	protected $ebookResources	 	= array();
	protected $activityResources 	= array();
	protected $otherResources 	 	= array();
	protected $activeTextResources	= array();
	
	function __construct()
	{
		parent::__construct();
	}
	
	function run()
	{
		$this->ebookResources	 	= Resource::getAllEbookResources();
		$this->activityResources 	= Resource::getAllActivityResources();
		$this->otherResources 	 	= Resource::getOtherResources();
		$this->activeTextResources 	= Resource::getAllActiveTextResources();
		
		$this->loadComponent('view-resources.php');
	}
}

AbstractPage::runPage('Main');