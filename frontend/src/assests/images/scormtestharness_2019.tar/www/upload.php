<?php 

require_once realpath(dirname(__FILE__)).'/../classes/Upload.php';


$page=new Upload();
$page->run();